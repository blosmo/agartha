Open model.blend in Blender 4.5.0. Materials and textures are packed in the file.
The assembly hierarchy preserves reusable components.
Rebuild geometry from this directory with:
blender --background --factory-startup --python-exit-code 1 --python scripts/showcase/build_models.py -- ./output verdant-conservatory final
Rendering uses your local computer. No hosted generation API is called.
