"""Preflight must reject invalid recipes before importing Blender."""
import copy
import json
import unittest
from pathlib import Path
from .asset_templates import build_template, _validate_expanded


class TemplatePreflightTests(unittest.TestCase):
    def test_computed_dimensions_are_bounded(self):
        for item in [
            {'kind':'sphere','material':'wood','position':[0,0,0],'radius':1e12},
            {'kind':'sphere','material':'wood','position':[0,0,0],'radius':1,'scale':[1e12,1,1]},
            {'kind':'cylinder','material':'wood','position':[0,0,0],'radius':1,'depth':1e12},
        ]:
            with self.subTest(item=item), self.assertRaises(ValueError):
                _validate_expanded([item], {'wood':{}})

    def test_false_branch_is_still_validated(self):
        definition=json.loads((Path(__file__).parents[2]/'scripts/showcase/chair-template.json').read_text())
        definition['parts'].append({'kind':'execute','when':False,'code':'invalid'})
        with self.assertRaises(ValueError):
            build_template(definition)

    def test_unicode_definition_uses_utf8_limit(self):
        definition=json.loads((Path(__file__).parents[2]/'scripts/showcase/chair-template.json').read_text())
        definition['description']='椅'*600
        # Geometry preflight is reached, rather than an ASCII-expanded byte limit.
        definition['parts'][0]['kind']='invalid'
        with self.assertRaisesRegex(ValueError,'Unsupported geometry'):
            build_template(definition)
